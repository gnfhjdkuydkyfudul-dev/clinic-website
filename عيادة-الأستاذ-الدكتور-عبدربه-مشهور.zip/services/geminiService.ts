
import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";

const SYSTEM_INSTRUCTION = `
أنت المساعد الذكي لعيادة الأستاذ الدكتور عبدربه مشهور. 
معلومات حيوية يجب الرد بها بدقة:
- الدكتور: أستاذ جراحة القولون والجهاز الهضمي بكلية طب قصر العيني.
- المواعيد: العيادة تعمل أيام الأحد والاثنين والأربعاء بداية من الساعة الخامسة مساءً.
- العنوان: 89 شارع المنيل – الدور الثالث – أعلى كشري الإمبراطور.
- رقم الهاتف (العيادة): 01099254368.
- واتساب الحجز: 01118250389.

تعليمات إضافية:
1. إذا طلب المستخدم تغيير صورة، استخدم أداة "updateSiteImage".
2. للردود العادية، استخدم اللغة العربية الفصحى الراقية.
3. كن ودوداً جداً ومطمئناً للمرضى.
`;

const updateSiteImageDeclaration: FunctionDeclaration = {
  name: 'updateSiteImage',
  parameters: {
    type: Type.OBJECT,
    description: 'تغيير صورة معينة في الموقع بناءً على وصف المستخدم',
    properties: {
      target: {
        type: Type.STRING,
        description: 'الهدف (hero, clinic, surgery, colon)',
      },
      prompt: {
        type: Type.STRING,
        description: 'وصف تفصيلي للصورة المطلوب توليدها باللغة الإنجليزية',
      },
    },
    required: ['target', 'prompt'],
  },
};

export class MedicalAI {
  private ai: any;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async getResponse(history: any[]) {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: history,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          tools: [{ functionDeclarations: [updateSiteImageDeclaration] }],
        },
      });

      if (response.functionCalls) {
        return { functionCalls: response.functionCalls };
      }

      return { text: response.text };
    } catch (error) {
      console.error("AI Error:", error);
      return { text: "عذراً، حدث خطأ في التواصل مع المساعد." };
    }
  }

  async generateImage(prompt: string) {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: [{ parts: [{ text: `Professional medical photography, high quality, medical design, clean aesthetic, no specific faces: ${prompt}` }] }],
        config: {
          imageConfig: { aspectRatio: "1:1" }
        }
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    } catch (error) {
      return null;
    }
    return null;
  }
}
