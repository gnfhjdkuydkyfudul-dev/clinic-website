
import { Service, Stat, Testimonial } from './types';

export const CLINIC_INFO = {
  phone: '01099254368',
  whatsapp: '01118250389',
  address: '89 شارع المنيل – الدور الثالث – أعلى كشري الإمبراطور',
  schedule: 'أيام الأحد – الاثنين – الأربعاء (بدءاً من 5 مساءً)',
  mapUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3454.2183944682496!2d31.2268798!3d30.0244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x145840ca84000001%3A0xe74f1c9d2f65a126!2zODkg2LTYp9ix2Lkg2KfZhNmF2YbZitmE!5e0!3m2!1sar!2seg!4v1710000000000!5m2!1sar!2seg'
};

export const SERVICES: Service[] = [
  {
    id: 'colon-surgery',
    title: 'جراحات القولون والمستقيم',
    description: 'علاج أورام القولون والمستقيم والتهابات الأمعاء المزمنة بأحدث التقنيات الجراحية.',
    icon: '🏥',
    image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'laparoscopy',
    title: 'جراحات المناظير المتقدمة',
    description: 'إجراء العمليات المعقدة من خلال فتحات صغيرة لتقليل الألم وسرعة الاستشفاء.',
    icon: '🔬',
    image: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'endoscopy',
    title: 'مناظير الجهاز الهضمي',
    description: 'تشخيص دقيق لمشاكل الجهاز الهضمي العلوي والسفلي وأخذ العينات اللازمة.',
    icon: '🩺',
    image: 'https://images.unsplash.com/photo-1583912267550-d44d7a125822?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'hemorrhoids',
    title: 'علاج البواسير والشرخ الشرجي',
    description: 'حلول نهائية لمشاكل القناة الشرجية باستخدام الليزر أو الدباسات الجراحية.',
    icon: '⚕️',
    image: 'https://images.unsplash.com/photo-1505751172107-573225a92771?auto=format&fit=crop&q=80&w=800'
  }
];

export const STATS: Stat[] = [
  { label: 'عملية ناجحة', value: 5000, suffix: '+' },
  { label: 'سنة خبرة', value: 25, suffix: '' },
  { label: 'مريض سعيد', value: 12000, suffix: '+' },
  { label: 'بحث علمي', value: 40, suffix: '+' }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    name: 'أحمد محمود',
    text: 'الدكتور عبدربه قمة في الأخلاق والعلم. أجريت عملية بالمنظار وكانت النتائج مذهلة.',
    rating: 5
  },
  {
    name: 'سارة علي',
    text: 'تشخيص دقيق جداً وراحة نفسية كبيرة في التعامل. العيادة متميزة بموقعها في المنيل.',
    rating: 5
  }
];
