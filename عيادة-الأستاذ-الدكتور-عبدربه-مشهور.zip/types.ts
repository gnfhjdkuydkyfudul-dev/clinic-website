
export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  image: string;
}

export interface Stat {
  label: string;
  value: number;
  suffix: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isImageAction?: boolean;
}

export interface Testimonial {
  id?: string;
  name: string;
  text: string;
  rating: number;
}

export interface SiteImages {
  hero: string;
  clinic: string;
  surgery: string;
  colon: string;
}

export const CLINIC_INFO = {
  phone: '01099254368',
  whatsapp: '01118250389',
  address: '89 شارع المنيل – الدور الثالث – أعلى كشري الإمبراطور',
  schedule: 'أيام الأحد – الاثنين – الأربعاء (بدءاً من 5 مساءً)',
  mapUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3454.2183944682496!2d31.2268798!3d30.0244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x145840ca84000001%3A0xe74f1c9d2f65a126!2zODkg2LTYp9ix2Lkg2KfZhNmF2YbZitmE!5e0!3m2!1sar!2seg!4v1710000000000!5m2!1sar!2seg'
};
