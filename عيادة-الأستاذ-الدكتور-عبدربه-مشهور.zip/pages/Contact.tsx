
import React from 'react';
import { CLINIC_INFO } from '../constants';

const Contact: React.FC = () => {
  return (
    <div className="py-16 space-y-16 dark:bg-dark-navy">
      <div className="container mx-auto px-4 md:px-8 text-center max-w-3xl space-y-6">
        <h1 className="text-4xl font-extrabold text-slate-900 dark:text-white">تواصل معنا</h1>
        <p className="text-xl text-slate-500 dark:text-slate-400 leading-relaxed">
          نحن في انتظاركم في عيادة المنيل لتقديم أفضل رعاية طبية ممكنة.
        </p>
      </div>

      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="bg-white dark:bg-slate-800 p-10 rounded-[2.5rem] shadow-xl border border-slate-100 dark:border-slate-700 text-center space-y-4 group hover:scale-105 transition-transform">
            <div className="w-20 h-20 bg-sky-100 dark:bg-sky-900/30 text-sky-600 rounded-full flex items-center justify-center text-4xl mx-auto">📞</div>
            <h3 className="text-xl font-bold dark:text-white">الهاتف</h3>
            <p className="text-slate-500 dark:text-slate-300 text-lg" dir="ltr">{CLINIC_INFO.phone}</p>
            <p className="text-xs text-slate-400 font-bold">للحجز والاستفسار الهاتفي</p>
          </div>
          
          <div className="bg-white dark:bg-slate-800 p-10 rounded-[2.5rem] shadow-xl border border-slate-100 dark:border-slate-700 text-center space-y-4 group hover:scale-105 transition-transform">
            <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-full flex items-center justify-center text-4xl mx-auto">💬</div>
            <h3 className="text-xl font-bold dark:text-white">واتساب</h3>
            <a href={`https://wa.me/20${CLINIC_INFO.whatsapp.substring(1)}`} target="_blank" rel="noopener noreferrer" className="inline-block bg-green-600 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:bg-green-700">تحدث معنا</a>
            <p className="text-slate-500 dark:text-slate-300" dir="ltr">{CLINIC_INFO.whatsapp}</p>
          </div>

          <div className="bg-white dark:bg-slate-800 p-10 rounded-[2.5rem] shadow-xl border border-slate-100 dark:border-slate-700 text-center space-y-4 group hover:scale-105 transition-transform">
            <div className="w-20 h-20 bg-red-100 dark:bg-red-900/30 text-red-600 rounded-full flex items-center justify-center text-4xl mx-auto">📍</div>
            <h3 className="text-xl font-bold dark:text-white">العنوان</h3>
            <p className="text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
              {CLINIC_INFO.address}
            </p>
            <p className="text-xs text-sky-600 font-bold">أحد، اثنين، أربعاء (5 مساءً)</p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-8">
        <div className="w-full h-[600px] rounded-[3.5rem] overflow-hidden shadow-2xl border-8 border-white dark:border-slate-800 group relative">
          <iframe 
            src={CLINIC_INFO.mapUrl}
            width="100%" 
            height="100%" 
            style={{ border: 0 }} 
            allowFullScreen={true} 
            loading="lazy" 
            className="grayscale hover:grayscale-0 transition-all duration-700"
          ></iframe>
          <div className="absolute top-8 right-8 bg-sky-600 text-white px-6 py-2 rounded-full font-bold shadow-xl">موقع العيادة بالمنيل</div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
