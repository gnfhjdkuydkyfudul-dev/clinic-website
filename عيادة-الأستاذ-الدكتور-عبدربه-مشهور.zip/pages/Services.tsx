
import React from 'react';
import { SERVICES } from '../constants';
import { Link } from 'react-router-dom';

const Services: React.FC = () => {
  return (
    <div className="py-16 space-y-24">
      <section className="container mx-auto px-4 md:px-8 text-center max-w-3xl space-y-6">
        <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900">تخصصاتنا وخدماتنا الطبية</h1>
        <p className="text-xl text-slate-500 leading-relaxed">
          نحن نقدم حزمة متكاملة من الخدمات الجراحية والتشخيصية المتطورة لضمان أعلى مستويات الرعاية الصحية لمرضانا.
        </p>
      </section>

      <section className="container mx-auto px-4 md:px-8 space-y-16">
        {SERVICES.map((service, idx) => (
          <div 
            key={service.id} 
            className={`flex flex-col ${idx % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} gap-12 items-center bg-white p-8 md:p-12 rounded-[2.5rem] shadow-xl border border-slate-100 hover:shadow-2xl transition-shadow`}
          >
            <div className="w-full lg:w-1/2 rounded-3xl overflow-hidden h-[400px]">
              {service.image ? (
                <img src={service.image} alt={service.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-sky-50 flex flex-col items-center justify-center text-sky-200 border-4 border-white">
                  <span className="text-9xl opacity-20">{service.icon}</span>
                  <p className="mt-4 text-sky-400 font-bold">صورة توضيحية للخدمة</p>
                </div>
              )}
            </div>
            <div className="w-full lg:w-1/2 space-y-6">
              <span className="text-5xl">{service.icon}</span>
              <h2 className="text-3xl font-bold text-slate-900">{service.title}</h2>
              <p className="text-lg text-slate-600 leading-relaxed">
                {service.description} تشمل خدماتنا في هذا التخصص أحدث المعايير الطبية العالمية مع توفير طاقم تمريض ومتابعة دقيقة قبل وبعد الإجراء الطبي.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-2 text-sky-600 font-semibold">
                  <span className="w-2 h-2 bg-sky-600 rounded-full"></span>
                  تشخيص دقيق
                </div>
                <div className="flex items-center gap-2 text-sky-600 font-semibold">
                  <span className="w-2 h-2 bg-sky-600 rounded-full"></span>
                  أحدث الأجهزة
                </div>
                <div className="flex items-center gap-2 text-sky-600 font-semibold">
                  <span className="w-2 h-2 bg-sky-600 rounded-full"></span>
                  تعقيم فائق
                </div>
                <div className="flex items-center gap-2 text-sky-600 font-semibold">
                  <span className="w-2 h-2 bg-sky-600 rounded-full"></span>
                  متابعة مستمرة
                </div>
              </div>
              <Link to="/booking" className="inline-block mt-4 bg-slate-900 text-white px-8 py-3 rounded-xl font-bold hover:bg-sky-600 transition-colors">
                احجز استشارة الآن
              </Link>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
};

export default Services;
