
import React, { useState } from 'react';
import { CLINIC_INFO } from '../constants';

const Booking: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    age: '',
    service: 'colon-surgery',
    message: '',
    date: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTimeout(() => {
      setSubmitted(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 1000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  if (submitted) {
    return (
      <div className="container mx-auto px-4 py-24 text-center space-y-8 animate-fadeIn dark:bg-dark-navy">
        <div className="w-24 h-24 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-full flex items-center justify-center mx-auto text-5xl">✓</div>
        <h1 className="text-4xl font-bold text-slate-900 dark:text-white">تم استلام طلبك!</h1>
        <p className="text-xl text-slate-500 dark:text-slate-400 max-w-xl mx-auto leading-relaxed">
          شكراً يا {formData.name}. سنقوم بالتواصل معك لتأكيد الموعد في أحد أيام عملنا (الأحد، الاثنين، الأربعاء) بعد الساعة 5 مساءً.
        </p>
        <div className="flex justify-center gap-4">
          <button onClick={() => setSubmitted(false)} className="bg-sky-600 text-white px-10 py-4 rounded-xl font-bold shadow-lg">العودة</button>
          <a href={`https://wa.me/20${CLINIC_INFO.whatsapp.substring(1)}`} className="bg-green-600 text-white px-10 py-4 rounded-xl font-bold shadow-lg">واتساب</a>
        </div>
      </div>
    );
  }

  return (
    <div className="py-16 container mx-auto px-4 md:px-8 dark:bg-dark-navy">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
        <div className="space-y-8">
          <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 dark:text-white border-r-8 border-sky-500 pr-4">احجز استشارتك</h1>
          <div className="bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] shadow-xl border border-slate-100 dark:border-slate-700 space-y-6">
            <div className="flex items-center gap-4">
              <span className="text-3xl">📅</span>
              <div>
                <h4 className="font-bold dark:text-white">أيام العمل</h4>
                <p className="text-slate-500 dark:text-slate-400">الأحد – الاثنين – الأربعاء</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-3xl">🕔</span>
              <div>
                <h4 className="font-bold dark:text-white">وقت البدء</h4>
                <p className="text-slate-500 dark:text-slate-400">من الساعة 5:00 مساءً</p>
              </div>
            </div>
            <div className="pt-4 border-t dark:border-slate-700">
              <p className="text-sm text-slate-400 italic font-medium">سيتم التواصل معكم هاتفياً لتأكيد رقم الكشف والموعد النهائي.</p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 p-8 md:p-12 rounded-[3rem] shadow-2xl border border-slate-100 dark:border-slate-700">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">الاسم الثلاثي</label>
              <input required type="text" name="name" value={formData.name} onChange={handleChange} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-sky-500 dark:text-white" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">رقم الهاتف</label>
              <input required type="tel" name="phone" value={formData.phone} onChange={handleChange} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-sky-500 dark:text-white" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">العمر</label>
                <input type="number" name="age" value={formData.age} onChange={handleChange} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-sky-500 dark:text-white" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">التخصص</label>
                <select name="service" value={formData.service} onChange={handleChange} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-sky-500 dark:text-white">
                  <option value="colon-surgery">جراحة القولون</option>
                  <option value="laparoscopy">جراحة منظار</option>
                  <option value="endoscopy">منظار تشخيصي</option>
                </select>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">الموعد المفضل</label>
              <input required type="date" name="date" value={formData.date} onChange={handleChange} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-sky-500 dark:text-white" />
            </div>
            <button type="submit" className="w-full bg-sky-600 text-white py-4 rounded-2xl font-bold text-lg shadow-xl hover:bg-sky-700 transition-all">إرسال طلب الحجز</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Booking;
