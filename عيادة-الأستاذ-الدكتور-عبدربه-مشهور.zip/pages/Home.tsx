
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { SERVICES, STATS, TESTIMONIALS as INITIAL_TESTIMONIALS, CLINIC_INFO } from '../constants';
import { Testimonial, SiteImages } from '../types';

interface HomeProps {
  siteImages: SiteImages;
}

const Home: React.FC<HomeProps> = ({ siteImages }) => {
  const [activeStat, setActiveStat] = useState(false);
  const [testimonials, setTestimonials] = useState<Testimonial[]>(INITIAL_TESTIMONIALS);
  const [currentSlide, setCurrentSlide] = useState(0);
  
  useEffect(() => {
    setActiveStat(true);
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  return (
    <div className="space-y-24 pb-24 dark:bg-dark-navy">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center overflow-hidden bg-slate-900 dark:bg-black text-white">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=1920" 
            alt="Medical BG" 
            className="w-full h-full object-cover opacity-30" 
          />
          <div className="absolute inset-0 bg-gradient-to-l from-slate-900 via-slate-900/80 to-transparent dark:from-black dark:via-black/80"></div>
        </div>

        <div className="container mx-auto px-4 md:px-8 relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center pt-20">
          <div className="animate-fadeIn space-y-8 text-center lg:text-right">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-sky-500/20 text-sky-400 rounded-full border border-sky-500/30 backdrop-blur-md">
              <span className="w-2 h-2 bg-sky-400 rounded-full animate-pulse"></span>
              <span className="text-sm font-bold">أستاذ دكتور بكلية طب قصر العيني</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-extrabold leading-tight">
              أ.د. عبدربه مشهور
            </h1>
            
            <p className="text-xl md:text-3xl font-medium text-sky-200">
              أستاذ جراحة القولون والجهاز الهضمي
              <span className="block text-lg md:text-xl mt-2 text-slate-300 font-normal">استشاري جراحات المناظير المتقدمة</span>
            </p>

            <p className="text-slate-400 max-w-xl mx-auto lg:mr-0 text-lg leading-relaxed dark:text-slate-300">
              رعاية طبية فائقة الجودة في قلب المنيل، نعتمد على أحدث التقنيات العالمية في جراحات المناظير لضمان أفضل النتائج بأقل تدخل جراحي.
            </p>

            <div className="flex flex-wrap justify-center lg:justify-start gap-4 pt-4">
              <Link to="/booking" className="bg-sky-500 hover:bg-sky-600 text-white px-10 py-4 rounded-2xl font-bold text-lg shadow-2xl shadow-sky-500/30 transition-all hover:-translate-y-1">
                احجز موعدك الآن
              </Link>
              <a href={`https://wa.me/201118250389`} target="_blank" rel="noopener noreferrer" className="bg-white/10 hover:bg-white/20 text-white px-10 py-4 rounded-2xl font-bold text-lg backdrop-blur-md border border-white/10 transition-all flex items-center gap-2">
                واتساب مباشر
              </a>
            </div>
          </div>

          <div className="hidden lg:block relative">
            <div className="relative w-full h-[650px] rounded-[4rem] overflow-hidden shadow-2xl border-8 border-white/5 animate-fadeIn [animation-delay:0.3s]">
              <img src={siteImages.hero} alt="Dr. Abdrabbuh Mashhour" className="w-full h-full object-cover object-top" />
              <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/60 to-transparent">
                <div className="flex gap-4">
                  <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 text-center flex-1">
                    <p className="text-2xl font-bold">25+</p>
                    <p className="text-xs text-sky-200 uppercase tracking-wider">سنة خبرة</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 text-center flex-1">
                    <p className="text-2xl font-bold">5000+</p>
                    <p className="text-xs text-sky-200 uppercase tracking-wider">عملية ناجحة</p>
                  </div>
                </div>
              </div>
            </div>
            {/* Decoration */}
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-sky-500/20 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-10 -right-10 w-60 h-60 bg-sky-600/10 rounded-full blur-3xl"></div>
          </div>
        </div>
      </section>

      {/* Quick Info Bar */}
      <section className="container mx-auto px-4 -mt-32 relative z-30">
        <div className="bg-white dark:bg-slate-800 rounded-[3rem] shadow-2xl p-8 md:p-12 border border-slate-100 dark:border-slate-700 backdrop-blur-xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 divide-y md:divide-y-0 md:divide-x md:divide-x-reverse divide-slate-100 dark:divide-slate-700">
            <div className="flex items-center gap-6 p-4">
              <div className="w-14 h-14 bg-sky-100 dark:bg-sky-900/30 rounded-2xl flex items-center justify-center text-3xl">📍</div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white mb-1">الموقع</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400 leading-tight">{CLINIC_INFO.address}</p>
              </div>
            </div>
            <div className="flex items-center gap-6 p-4">
              <div className="w-14 h-14 bg-sky-100 dark:bg-sky-900/30 rounded-2xl flex items-center justify-center text-3xl">🕒</div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white mb-1">المواعيد</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400">{CLINIC_INFO.schedule}</p>
              </div>
            </div>
            <div className="flex items-center gap-6 p-4">
              <div className="w-14 h-14 bg-sky-100 dark:bg-sky-900/30 rounded-2xl flex items-center justify-center text-3xl">📞</div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white mb-1">للحجز</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400" dir="ltr">{CLINIC_INFO.phone}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Colon & Health Awareness Section */}
      <section className="container mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center overflow-hidden">
        <div className="space-y-8 animate-slideInRight">
          <div className="space-y-4">
            <h2 className="text-3xl md:text-5xl font-bold text-slate-900 dark:text-white border-r-8 border-sky-500 pr-6">
              متخصصون في صحة <br /> <span className="text-sky-600">الجهاز الهضمي</span>
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-400 leading-relaxed max-w-lg">
              نحن نوفر تشخيصاً دقيقاً وعلاجاً متطوراً لأمراض القولون، المستقيم، وأورام الجهاز الهضمي باستخدام أحدث جراحات المناظير التي تضمن الشفاء السريع والحد الأدنى من التدخل.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { title: 'تشخيص مبكر', desc: 'لأورام القولون والمستقيم بدقة عالية.' },
              { title: 'مناظير متطورة', desc: 'أحدث التقنيات لتقليل فترات النقاهة.' },
              { title: 'خبرة أكاديمية', desc: 'أستاذ بكلية طب قصر العيني.' },
              { title: 'علاجات الليزر', desc: 'للبواسير والشرخ الشرجي بدون ألم.' },
            ].map((item, i) => (
              <div key={i} className="p-6 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-100 dark:border-slate-700/50 hover:bg-sky-50 dark:hover:bg-sky-900/10 transition-colors group">
                <h4 className="font-bold text-sky-600 dark:text-sky-400 mb-2 group-hover:translate-x-1 transition-transform">{item.title}</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="relative group">
          <div className="grid grid-cols-2 gap-6 items-center">
            <div className="space-y-6">
              <div className="h-64 rounded-[2.5rem] overflow-hidden shadow-2xl transform group-hover:-translate-y-2 transition-transform duration-500 border-4 border-white dark:border-slate-800">
                <img src={siteImages.colon} className="w-full h-full object-cover" alt="Colon Health" />
              </div>
              <div className="h-48 rounded-[2rem] overflow-hidden shadow-xl transform group-hover:translate-y-2 transition-transform duration-500 border-4 border-white dark:border-slate-800">
                <img src={siteImages.surgery} className="w-full h-full object-cover" alt="Medical Tech" />
              </div>
            </div>
            <div className="h-80 rounded-[3rem] overflow-hidden shadow-2xl border-4 border-white dark:border-slate-800">
              <img src={siteImages.clinic} className="w-full h-full object-cover" alt="Clinic Interior" />
            </div>
          </div>
          {/* Glass Card */}
          <div className="absolute -bottom-10 -left-10 bg-white/80 dark:bg-slate-800/80 backdrop-blur-xl p-8 rounded-[2rem] shadow-2xl border border-white/20 hidden md:block max-w-xs animate-fadeIn">
            <p className="text-sky-600 font-bold mb-2">رسالة الدكتور:</p>
            <p className="text-slate-600 dark:text-slate-300 text-sm italic leading-relaxed">
              "صحة مريضنا وراحته هي أولويتنا القصوى، نسعى دائماً لتقديم أحدث ما وصل إليه العلم بكل أمانة وإتقان."
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="bg-slate-50 dark:bg-slate-900/50 py-24">
        <div className="container mx-auto px-4 md:px-8">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-4xl font-bold dark:text-white">تخصصاتنا الطبية</h2>
            <p className="text-slate-500 dark:text-slate-400">نقدم رعاية شاملة متخصصة بأعلى المعايير العالمية</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {SERVICES.map((service) => (
              <div key={service.id} className="group bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] shadow-lg border border-slate-100 dark:border-slate-700 hover:shadow-2xl hover:-translate-y-2 transition-all">
                <div className="w-16 h-16 bg-sky-100 dark:bg-sky-900/30 rounded-2xl flex items-center justify-center text-4xl mb-6 group-hover:scale-110 transition-transform">{service.icon}</div>
                <h3 className="text-xl font-bold mb-4 dark:text-white">{service.title}</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed mb-6 line-clamp-3">
                  {service.description}
                </p>
                <Link to="/services" className="text-sky-600 dark:text-sky-400 font-bold text-sm inline-flex items-center gap-2 group-hover:gap-4 transition-all">
                  اقرأ المزيد
                  <span>←</span>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Location Details Section */}
      <section className="container mx-auto px-4 md:px-8">
        <div className="bg-slate-900 dark:bg-black rounded-[4rem] overflow-hidden flex flex-col lg:flex-row shadow-2xl">
          <div className="w-full lg:w-1/2 p-12 md:p-20 space-y-8 flex flex-col justify-center text-white">
            <h2 className="text-4xl font-bold">تفضل بزيارتنا في المنيل</h2>
            <div className="space-y-6">
              <div className="flex gap-4">
                <span className="text-sky-500 text-2xl">📍</span>
                <div>
                  <h4 className="font-bold text-lg mb-1">العنوان بالتفصيل</h4>
                  <p className="text-slate-400 leading-relaxed">{CLINIC_INFO.address}</p>
                </div>
              </div>
              <div className="flex gap-4">
                <span className="text-sky-500 text-2xl">⏰</span>
                <div>
                  <h4 className="font-bold text-lg mb-1">ساعات العمل الرسمية</h4>
                  <p className="text-slate-400">الأحد، الاثنين، الأربعاء (بدءاً من 5 مساءً)</p>
                </div>
              </div>
            </div>
            <Link to="/contact" className="inline-block bg-white text-slate-900 px-10 py-4 rounded-2xl font-bold hover:bg-sky-500 hover:text-white transition-all w-fit">
              خرائط جوجل
            </Link>
          </div>
          <div className="w-full lg:w-1/2 h-[400px] lg:h-auto grayscale hover:grayscale-0 transition-all duration-1000">
            <iframe 
              src={CLINIC_INFO.mapUrl}
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen={true} 
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
